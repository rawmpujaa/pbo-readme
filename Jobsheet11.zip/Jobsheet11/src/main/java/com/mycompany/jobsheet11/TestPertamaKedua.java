/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet11;

/**
 *
 * @author user
 */

public class TestPertamaKedua {
    //created by 22343010_Rawim Puja Aviola
    public static void main (String args[]) {
        Kedua D2 = new Kedua();
        D2.BacaSuper();
        D2.info();
        
        Pertama S1 = new Pertama();
        S1.terprotek();
        S1.info();
    } 
}
