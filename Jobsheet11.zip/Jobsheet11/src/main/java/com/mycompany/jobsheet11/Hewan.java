/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet11;

import java.util.Locale;

/**
 *
 * @author user
 */
public class Hewan {
    //created by 22343010_Rawim Puja Aviola
    public static void testClassMethod(){
        System.out.println("The Class Method in Hewan");
    }
    
    public void testInstanceMethod(){
        System.out.println("The Instance Method in Hewan");
    }          
}
