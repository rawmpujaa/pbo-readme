/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet11;

/**
 *
 * @author user
 */
public class KonstruktorSuperKelas {
    //created by 22343010_Rawim Puja Aviola
    public static void main (String[] args){
        Employ programer1 = new Employ("12345678" , "Budi", 33);
        programer1.info();
    } 
}
