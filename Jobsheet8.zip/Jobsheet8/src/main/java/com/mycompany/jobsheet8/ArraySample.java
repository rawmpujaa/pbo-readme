/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet8;

/**
 *
 * @author user
 */

public class ArraySample {
    //created by 22343010_Rawim Puja Aviola
    // Pengaksesan element array
    public static void main(String[] args) {
        int[] ages = new int[100];
        for (int i = 0; i < 100; i++) {
            System.out.print(ages[i]);
        }
    }
}