/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet8;

/**
 *
 * @author user
 */
public class ArraySample3 {
    //created by 22343010_Rawim Puja Aviola
    // Array Multidimensi
    public static void main(String[]args) {
        //String array 4 baris x 2 kolom
        String[][] dogs = {{"Terry", "brwon"}, //baris ke 0
                           {"Kristin", "white"}, //baris ke 1
                           {"Toby", "gray"}, //baris ke 2
                           {"Fido", "black"} //baris ke 3
                          };
        System.out.println(dogs[0][0]);
        // mengakses variabel dogs dengan indeks baris 0, indeks kolom 0
        }
    }
