/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet8;

/**
 *
 * @author user
 */
public class Tugas1_HariDalamSeminggu {
    //created by 22343010_Rawim Puja Aviola
    public static void main(String[] args) {
        String[] days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};

        System.out.println("Hari dalam Seminggu:");
        
        // Menggunakan for-loop untuk mencetak nilai dari array
        for (int i = 0; i < days.length; i++) {
            System.out.println(days[i]);
        }
    }
}
