/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet8;

/**
 *
 * @author user
 */

import javax.swing.JOptionPane;

public class Tugas2_NomorTerbesar {
    //created by 22343010_Rawim Puja Aviola
    public static void main(String[] args) {
        int jumlahNomor = 10;
        int[] nomor = new int[jumlahNomor];

        // Menggunakan JOptionPane untuk meminta input dari pengguna
        for (int i = 0; i < jumlahNomor; i++) {
            String input = JOptionPane.showInputDialog("Masukkan nomor ke-" + (i + 1));
            nomor[i] = Integer.parseInt(input);
        }

        // Mencari nomor terbesar
        int terbesar = nomor[0];
        for (int i = 1; i < jumlahNomor; i++) {
            if (nomor[i] > terbesar) {
                terbesar = nomor[i];
            }
        }

        // Menampilkan hasil
        JOptionPane.showMessageDialog(null, "Nomor terbesar yang dimasukkan adalah: " + terbesar);
    }   
}
