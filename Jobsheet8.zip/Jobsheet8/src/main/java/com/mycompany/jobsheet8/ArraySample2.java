/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet8;

/**
 *
 * @author user
 */
public class ArraySample2 {
    //created by 22343010_Rawim Puja Aviola
    // Panjang Array
    public static void main(String[] args) {
        int[] ages = new int[100];
        for (int i = 0; i < ages.length; i++) {
            System.out.print(ages[i]);
        }
    }
}
