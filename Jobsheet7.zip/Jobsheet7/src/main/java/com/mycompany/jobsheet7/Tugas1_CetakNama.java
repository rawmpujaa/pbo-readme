/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet7;

/**
 *
 * @author user
 */
public class Tugas1_CetakNama {
    //created by 22343010_Rawim Puja Aviola
    public static void main(String[] args) {
        String nama = "Rawim Puja Aviola";
        int jumlahCetak = 100;

        // Menggunakan perulangan for
        System.out.println("Perulangan for:");
        for (int i = 0; i < jumlahCetak; i++)
            System.out.println(nama);

        // Menggunakan perulangan while
        System.out.println("\nPerulangan while:");
        int j = 0;
        while (j < jumlahCetak) {
            System.out.println(nama);
            j++;
        }

        // Menggunakan perulangan do-while
        System.out.println("\nPerulangan do-while:");
        int k = 0;
        do {
            System.out.println(nama);
            k++;
        } while (k < jumlahCetak);
    }
}
