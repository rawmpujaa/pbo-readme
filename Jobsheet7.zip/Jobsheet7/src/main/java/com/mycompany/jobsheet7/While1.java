/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet7;

/**
 *
 * @author user
 */
public class While1 {
    //created by 22343010_Rawim Puja Aviola
    public static void main(String[]args){
        int i = 0;
        while (i <= 10){
            System.out.println(i);
            i++;
        }
    }
}
