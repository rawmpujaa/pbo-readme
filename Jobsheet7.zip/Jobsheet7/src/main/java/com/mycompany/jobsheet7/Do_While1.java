/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet7;

/**
 *
 * @author user
 */
public class Do_While1 {
    //created by 22343010_Rawim Puja Aviola
    public static void main(String[]args){
        int i = 0;
        do {
            System.out.println(i);
            i++;
        }
        while (i < 10);
    }
}
