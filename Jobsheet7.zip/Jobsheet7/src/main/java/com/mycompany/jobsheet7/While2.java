/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet7;

/**
 *
 * @author user
 */
public class While2 {
    //created by 22343010_Rawim Puja Aviola
    public static void main(String[]args){
        int i = 20;
        while (i <= 10){
            System.out.println("Pemograman Berorintasi Objek");
            i++;
        }
    }   
}
/*
Dalam program ini, variabel i diinisialisasi dengan nilai 20. 
Namun, kondisi while memeriksa apakah i kurang dari atau sama dengan 10. 
Karena 20 tidak kurang dari atau sama dengan 10, 
maka blok while tidak akan dieksekusi, dan outputnya tidak akan muncul.
*/
