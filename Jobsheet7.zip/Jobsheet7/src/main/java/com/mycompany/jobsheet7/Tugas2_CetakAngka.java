/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet7;

/**
 *
 * @author user
 */
public class Tugas2_CetakAngka {
    //created by 22343010_Rawim Puja Aviola
    public static void main(String[] args) {
        
    // Menggunakan perulangan for
    System.out.println("Perulangan for:");
    for (int i = 100; i >= 1; i--) {
        System.out.print(i + " ");
    }

    // Menggunakan perulangan while
    System.out.println("\n\nPerulangan while:");
    int j = 100;
    while (j >= 1) {
        System.out.print(j + " ");
        j--;
    }

    // Menggunakan perulangan do-while
    System.out.println("\n\nPerulangan do-while:");
    int k = 100;
        do {
            System.out.print(k + " ");
            k--;
        } while (k >= 1);
    }
}
