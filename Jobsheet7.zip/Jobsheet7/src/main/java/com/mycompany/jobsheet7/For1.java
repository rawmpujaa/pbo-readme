/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet7;

/**
 *
 * @author user
 */
public class For1 {
    //created by 22343010_Rawim Puja Aviola
    public static void main(String[]args){
        int bilangan;
        for (bilangan = 20; bilangan <= 100; bilangan += 10)
            System.out.println(bilangan);
    }
}
