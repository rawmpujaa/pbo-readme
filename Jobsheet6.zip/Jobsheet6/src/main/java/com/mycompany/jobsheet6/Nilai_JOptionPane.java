/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet6;

/**
 *
 * @author user
 */

import javax.swing.JOptionPane;

public class Nilai_JOptionPane {
    //created by 22343010_Rawim Puja Aviola
    public static void main(String[] args) {
            double nilai1 = Double.parseDouble(JOptionPane.showInputDialog("Masukkan nilai ujian ke-1: "));
            double nilai2 = Double.parseDouble(JOptionPane.showInputDialog("Masukkan nilai ujian ke-2: "));
            double nilai3 = Double.parseDouble(JOptionPane.showInputDialog("Masukkan nilai ujian ke-3: "));

            double rataRata = (nilai1 + nilai2 + nilai3) / 3;

            JOptionPane.showMessageDialog(null, "Rata-rata nilai: " + rataRata);

            if (rataRata >= 60) {
                JOptionPane.showMessageDialog(null, ":-)");
            } else {
                JOptionPane.showMessageDialog(null, ":-(");
            }
    }
}