/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet5;

/**
 *
 * @author user
 */

import javax.swing.JOptionPane;

public class GetInputFromKeyboard2 {
    // created by 22343010_Rawim Puja Aviola
    public static void main(String[] args) {
        String name="", hoby="";
        
        name = JOptionPane.showInputDialog("Nama Anda: ");
        name = JOptionPane.showInputDialog("Hobi Anda: ");
        
        String msg = "Jadi Hobi Anda "+name+". "
                + "Hobi yang bagus "+hoby;
        
        JOptionPane.showMessageDialog(null, msg);
        
        System.out.println("Jadi Hobi Anda "+hoby+". Hobi yang bagus" +name);
    }
}
