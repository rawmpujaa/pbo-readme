/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet5;

/**
 *
 * @author user
 */

import javax.swing.JOptionPane;

public class KataTerakhir_JOptionPane {
    // created by 22343010_Rawim Puja Aviola
    /* saya membuat tugas ini berdasarkan 
    latihan GetInputFromKeyboard2 */
    
    public static void main(String[] args) {
        String word1="", word2="", word3="";
        
        word1 = JOptionPane.showInputDialog("Word1: ");
        word2 = JOptionPane.showInputDialog("Word2: ");
        word3= JOptionPane.showInputDialog("Word3: ");
        
        String msg = "" + word1 + " " + word2 + " " + word3;

        JOptionPane.showMessageDialog(null, msg);
        
        System.out.println("" + word1 + " " + word2 + " " + word3);
    }
}
