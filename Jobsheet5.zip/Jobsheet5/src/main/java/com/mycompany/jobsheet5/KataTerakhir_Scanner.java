/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet5;

/**
 *
 * @author user
 */

import java.util.Scanner;

public class KataTerakhir_Scanner {
    // created by 22343010_Rawim Puja Aviola
    /* saya membuat tugas ini berdasarkan 
    latihan Scanner1 */
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.print("Enter Word1: ");
        String word1 = in.nextLine();
        
        System.out.print("Enter Word2: ");
        String word2 = in.nextLine();
        
        System.out.print("Enter Word3: ");
        String word3 = in.nextLine();
        
        System.out.println(word1 + "" + word2 + "" + word3);
    }
}