/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet5;

/**
 *
 * @author user
 */

import java.util.Scanner;

public class Scanner1 {
    // created by 22343010_Rawim Puja Aviola
    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        
        System.out.print("Masukkan Nama Lengkap: ");
        String nama = in.nextLine();
        
        System.out.print("Masukkan NIM: ");
        int NIM = in.nextInt();
        
        System.out.print("Masukkan Nilai: ");
        float nilai = in.nextFloat();
        
        System.out.println("\nNama : " + nama +
                           "\nNIM : " + NIM + 
                           "\nNilai : " + nilai);
    }
}
