/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet5;

/**
 *
 * @author user
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class KelasTerakhir_BufferedReader {
    // created by 22343010_Rawim Puja Aviola
    /* saya membuat tugas ini berdasarkan 
    latihan GetInputFromKeyboard1 */
    
    public static void main(String[] args) {
        BufferedReader dataIn = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.print("Enter word1: ");
            String word1 = dataIn.readLine();

            System.out.print("Enter word2: ");
            String word2 = dataIn.readLine();

            System.out.print("Enter word3: ");
            String word3 = dataIn.readLine();

            System.out.println(word1 + " " + word2 + " " + word3);
        } 
        
        catch (IOException e) {
            System.out.println("Error reading input from the keyboard.");
        }
    }
}
