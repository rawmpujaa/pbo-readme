/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet10;

/**
 *
 * @author user
 */

public class Tugas2_Mahasiswa {
    //created by 22343010_Rawim Puja Aviola
    String nama;
    int nim;
    String semester;
    double ip;

    public Tugas2_Mahasiswa(String nama, int nim, String semester, double ipSemester) {
        this.nama = nama;
        this.nim = nim;
        this.semester = semester;
        this.ip = ip;
    }

    public int hitungJumlahSKS() {
        if (ip >= 3.5) {
            return 24;
        } else if (ip>= 3.0) {
            return 22;
        } else if (ip >= 2.5) {
            return 20;
        } else if (ip >= 2.0) {
            return 18;
        } else {
            return 15;
        }
    }

    // Method untuk menampilkan informasi mahasiswa
    public void tampilkanInformasi() {
        System.out.println("Nama Mahasiswa: " + nama);
        System.out.println("NIM: " + nim);
        System.out.println("Semester: " + semester);
        System.out.println("IP Semester ini: " + ip);
        System.out.println("Jumlah SKS yang dapat diambil: " + hitungJumlahSKS() + " SKS");
    }

    // Main method sebagai contoh penggunaan
    public static void main(String[] args) {
        // Membuat objek mahasiswa
        Tugas2_Mahasiswa mahasiswa = new Tugas2_Mahasiswa("Joni", 12345, "V", 3.50);

        // Menampilkan informasi mahasiswa
        mahasiswa.tampilkanInformasi();
    }
}

