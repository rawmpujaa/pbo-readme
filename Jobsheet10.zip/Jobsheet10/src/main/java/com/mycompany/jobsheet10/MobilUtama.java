/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet10;

/**
 *
 * @author user
 */
public class MobilUtama {
    //created by 22343010_Rawim Puja Aviola    
    public static void main (String[]args) {
        Mobil Honda = new Mobil();
        Honda.merk = "Civic";
        Honda.warna = "Hitam";
        Honda.tahunproduksi = 2020;
        
        System.out.println("Merek\t: " + Honda.merk);
        System.out.println("Warma\t: " + Honda.warna);
        System.out.println("Tahun\t: " + Honda.tahunproduksi);
        
        Honda.Maju();
        Honda.Mundur();
    }
}
