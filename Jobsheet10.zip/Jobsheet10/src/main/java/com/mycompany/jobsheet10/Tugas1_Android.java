/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet10;

/**
 *
 * @author user
 */
        
public class Tugas1_Android {
    //created by 22343010_Rawim Puja Aviola
    public static void main(String[]args) {
        Tugas1_AndroidUtama myAndroid = new Tugas1_AndroidUtama();
        
        myAndroid.nyala();
        myAndroid.panggilan();
        myAndroid.sms();
        myAndroid.shutdown();        
    }
}
