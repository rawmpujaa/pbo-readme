/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet10;

/**
 *
 * @author user
 */
public class Mahasiswa {
    //created by 22343010_Rawim Puja Aviola
    String nama, jur, univ;
    int nim;
}
