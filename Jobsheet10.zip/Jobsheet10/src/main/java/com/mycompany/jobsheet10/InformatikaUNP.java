/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet10;

/**
 *
 * @author user
 */
public class InformatikaUNP {
    //created by 22343010_Rawim Puja Aviola
    public static void main(String[] args){
        Mahasiswa Informatika = new Mahasiswa();
        Mahasiswa Elektronika = new Mahasiswa();
        
        Informatika.nama = "Rawim Puja Aviola";
        Informatika.nim = 1;
        Informatika.jur = "S1 Informatika";
        Informatika.univ = "Universitas Negeri Padang";
        
        Elektronika.nama = "Annisa";
        Elektronika.nim = 2;
        Elektronika.jur = "S1 Elektronika";
        Elektronika.univ = "Universitas Negeri Padang";    
        
        System.out.println("Data Mahasiswa Informatika");
        System.out.println("Nama: " + Informatika.nama);
        System.out.println("NIM: " + Informatika.nim);
        System.out.println("Jurusan: " + Informatika.jur);
        System.out.println("Status: " + Informatika.univ);
        
        System.out.println("Data Mahasiswa Informatika");
        System.out.println("Nama: " + Elektronika.nama);
        System.out.println("NIM: " + Elektronika.nim);
        System.out.println("Jurusan: " + Elektronika.jur);
        System.out.println("Status: " + Elektronika.univ);
        
    }
}
