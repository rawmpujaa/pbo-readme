/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet10;

/**
 *
 * @author user
 */

import java.util.Scanner;

public class Manusia {
    //created by 22343010_Rawim Puja Aviola
    String nama, tempat_lahir, tgl_lahir;
    int berat_badan, tinggi_badan;
    
    public void inputData(){
        Scanner input = new Scanner (System.in);
        System.out.println("Masukkan nama lengkap\t: ");
        nama = input.nextLine();
        System.out.println("Masukkan tempat lahir\t: ");
        tempat_lahir = input.nextLine();
        System.out.println("Masukkan tanggal lahir\t: ");
        tgl_lahir = input.nextLine();
        System.out.println("Masukkan berat badan\t: ");
        berat_badan = input.nextInt();
        System.out.println("Masukkan tinggi badan\t: ");
        tinggi_badan = input.nextInt();
    }
    
    public void identitas(){
        System.out.println("Nama saya \t: " + nama);
        System.out.println("Tempat Lahir \t: " + tempat_lahir);
        System.out.println("Tanggal Lahir \t: " + tgl_lahir);
        System.out.println("Berat Badan \t: " + berat_badan + " kg");
        System.out.println("Tinggi Badan \t: " + tinggi_badan + " cm");
    }
    
    public static void main(String[]args){
        Manusia A = new Manusia();
        A.inputData();
        A.identitas();
    }
}
