/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet12;

/**
 *
 * @author user
 */

interface AktivitasPagi {
    //created by 22343010_Rawim Puja Aviola
    abstract void lari();
    
    abstract void berenang();
}
