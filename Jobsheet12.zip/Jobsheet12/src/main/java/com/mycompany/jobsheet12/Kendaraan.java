/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet12;

/**
 *
 * @author user
 */

public class Kendaraan {
    //created by 22343010_Rawim Puja Aviola
    double hargaDasar = 1000000;
    public void tampilkanHarga(){
        System.out.println("Harga kendaraan adalah Rp. " + hargaDasar);
    }
}
