/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet2;

/**
 *
 * @author user
 */
public class ProgramWithCaseSensitive {
    // created by 22343010_Rawim Puja Aviola
    public static void main(String args []) {
        // Deklarasi String
        String nama = "Identitas";
        String Nama = "Nama Lengkap";
        String NAMA = "Rawim Puja";
        
        // Menampilkan String 
        System.out.println(nama);
        System.out.println(Nama);
        System.out.println(NAMA);
        
        /*  Setelah menambahkan string maka
            dapat ditampilkan dengan println
        */
    } 
}
