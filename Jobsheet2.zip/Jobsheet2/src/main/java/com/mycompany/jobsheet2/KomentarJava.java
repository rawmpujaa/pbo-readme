/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet2;

/**
 *
 * @author user
 */
public class KomentarJava {
    // created by 22343010_Rawim Puja Aviola
    public static void main(String[] args) { 
        System.out.println("Single line comment above");
        // comment line 1
        System.out.println("Multi line comment below");
        /*  comment line 2
            comment line 3
            comment line 4
        */
    }
}
