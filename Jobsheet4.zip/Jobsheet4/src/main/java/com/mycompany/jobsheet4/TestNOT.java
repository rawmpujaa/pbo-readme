/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet4;

/**
 *
 * @author user
 */
public class TestNOT {
    // created by 22343010_Rawim Puja Aviola   
    public static void main(String[] args) {
        boolean val1 = true;
        boolean val2 = false;
        
        System.out.println(!val1);
        System.out.println(!val2);
    }
}
