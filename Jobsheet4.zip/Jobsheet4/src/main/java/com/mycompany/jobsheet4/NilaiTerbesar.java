/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet4;

/**
 *
 * @author user
 */
public class NilaiTerbesar {
    // created by 22343010_Rawim Puja Aviola
        public static void main(String[] args) {
        int num1 = 10;
        int num2 = 23;
        int num3 = 5;

        // Menggunakan Kondisi Operator untuk mencari nilai terbesar
        int NilaiTerbesar = (num1 > num2) ? ((num1 > num3) ? num1 : num3) : ((num2 > num3) ? num2 : num3);

        // Menampilkan nilai masing-masing angka
        System.out.println("number 1 = " + num1);
        System.out.println("number 2 = " + num2);
        System.out.println("number 3 = " + num3);

        // Menampilkan nilai terbesar
        System.out.println("Nilai Terbesar adalah angka = " + NilaiTerbesar);
    }
}
