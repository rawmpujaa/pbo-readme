/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet4;

/**
 *
 * @author user
 */
public class MenghitungRataRata {
    // created by 22343010_Rawim Puja Aviola
        public static void main(String[] args) {
        int num1 = 10;
        int num2 = 20;
        int num3 = 45;

        // Menghitung rata-rata
        double rata = (num1 + num2 + num3) / 3.0;

        // Menampilkan nilai masing-masing angka
        System.out.println("number 1 = " + num1);
        System.out.println("number 2 = " + num2);
        System.out.println("number 3 = " + num3);

        // Menampilkan rata-rata
        System.out.println("Rata-rata = " + rata);
    }
}
