/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet1;

/**
 *
 * @author user
 */
public class TheTree {
    // created by 22343010_Rawim Puja Aviola
    public static void main(String[] args) {
        System.out.println("I think I shall never see,");
        System.out.println("a poem as lovely as a tree.");
        System.out.println("A tree whose hungry mouth is pressed");
        System.out.println("Against the Earth's sweet flowing breast");  
    }
}
