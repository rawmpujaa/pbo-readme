/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet1;

/**
 *
 * @author user
 */
public class KesanPembelajaran {
    // created by 22343010_Rawim Puja Aviola
    public static void main (String[] args){
        System.out.println("Kesan pembelajaran saya selama perkuliahan PPBO yaitu sangat cemas.");
        System.out.println("Saya cemas tidak mampu mengikuti atau menyesuaikan diri pada pembelajaran ini.");
        System.out.println("Namun bagi saya itu semua hanya permulaan, jika saya jalani dengan baik maka akan sesuai.");
        System.out.println("Sama halnya ketika awal perkuliahan, semua begitu baru. Semua bermula dari langkah yang baik.\n");
        System.out.println("Saya merasa apapun itu di dalam pembelajaran PPBO nantinya dapat saya kuasai,");   
        System.out.println("apa yang sebelumnya masih baru bagi saya akan saya usahakan agar terbiasa.");
        System.out.println("Saya berterima kasih pada Bapak yang telah mengajarkan kami terutama saya,");
        System.out.println("dengan bimbingan serta arahan Bapak saya bisa mengetahui pembelajaran ini.\n");
        System.out.println("Terakhir, semoga ilmu yang disampaikan Bapak dapat saya terapkan nantinya.");
        System.out.println("Terima Kasih...");
    }
}
