/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet3;

/**
 *
 * @author user
 */
public class TugasVariabelTabel {
    // created by 22343010_Rawim Puja Aviola
    public static void main(String[]args) {
        int number = 10; // number bertipe int
        char letter = 'a'; // letter bertipe char
        boolean result = true; // result bertipe boolean
        String str = "hello"; // str bertipe String
        
        System.out.println("Number = " + number);
        System.out.println("letter = " + letter);
        System.out.println("result = " + result);
        System.out.println("str = " + str);
    }
}
