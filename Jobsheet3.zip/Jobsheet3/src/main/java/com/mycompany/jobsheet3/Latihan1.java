/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jobsheet3;

/**
 *
 * @author user
 */
public class Latihan1 {
    // created by 22343010_Rawim Puja Aviola
    public static void main(String[]args) {
        int a = 10;
        short s = 2;
        byte b = 6;
        long l = 125362133223l; 
        float f = 65.20298f;
        double d = 876.765d;
        
       System.out.println("The integer variable is "+ a);
       System.out.println("The short variable is "+ s);
       System.out.println("The byte variable is "+ b);
       System.out.println("The long variable is "+ l);
       System.out.println("The float variable is "+ f);
       System.out.println("The double variable is "+ d);
    }
}
